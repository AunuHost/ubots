__MODULE__ = "ꜱᴀɴɢᴍᴀᴛᴀ"
__HELP__ = """
<blockquote><b>Bantuan untuk sangmata

perintah : <code>{0}sg</code> [reply/user]
    memeriksa histori name pengguna telegram</b></blockquote>
"""
