git pull && python3 -m AunuUbot
